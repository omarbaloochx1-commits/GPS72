package com.example.gps72;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements LocationListener, SensorEventListener {
    private static final int REQ_LOCATION = 72;
    private LocationManager locationManager;
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private GnssStatus.Callback gnssCallback;
    private GpsView gpsView;
    private Location lastLocation;
    private String status = "در انتظار مجوز مکان‌یابی";
    private int satellites = 0;
    private float heading = Float.NaN;
    private boolean tracking = false;
    private final ArrayList<Location> track = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        gpsView = new GpsView(this);
        setContentView(gpsView);
        requestLocationAccess();
    }

    private boolean hasFineLocation() {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationAccess() {
        if (Build.VERSION.SDK_INT >= 23 && !hasFineLocation()) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
        } else startGps();
    }

    private void startGps() {
        if (!hasFineLocation()) {
            status = "مجوز مکان دقیق داده نشده";
            gpsView.invalidate();
            return;
        }
        try {
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                status = "GPS خاموش است؛ مکان‌یابی را روشن کن";
                gpsView.invalidate();
                return;
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
            if (Build.VERSION.SDK_INT >= 24) {
                gnssCallback = new GnssStatus.Callback() {
                    @Override public void onSatelliteStatusChanged(GnssStatus s) {
                        int n = 0;
                        for (int i = 0; i < s.getSatelliteCount(); i++) if (s.usedInFix(i)) n++;
                        satellites = n;
                        gpsView.invalidate();
                    }
                };
                locationManager.registerGnssStatusCallback(gnssCallback, new android.os.Handler(Looper.getMainLooper()));
            }
            status = "در حال جست‌وجوی ماهواره‌ها…";
            if (rotationSensor != null) sensorManager.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_UI);
            Location cached = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (cached != null && lastLocation == null) onLocationChanged(cached);
        } catch (SecurityException e) {
            status = "مجوز GPS رد شده است";
        } catch (Exception e) {
            status = "خطا در راه‌اندازی GPS";
        }
        gpsView.invalidate();
    }

    private void stopGps() {
        try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
        if (Build.VERSION.SDK_INT >= 24 && gnssCallback != null) {
            try { locationManager.unregisterGnssStatusCallback(gnssCallback); } catch (Exception ignored) {}
            gnssCallback = null;
        }
        sensorManager.unregisterListener(this);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_LOCATION) {
            if (hasFineLocation()) startGps();
            else {
                status = "برای مختصات دقیق، مجوز مکان دقیق لازم است";
                gpsView.invalidate();
            }
        }
    }

    @Override public void onLocationChanged(Location location) {
        lastLocation = new Location(location);
        status = "موقعیت GPS دریافت شد";
        if (tracking) {
            if (track.isEmpty() || track.get(track.size()-1).distanceTo(location) > 3f) {
                track.add(new Location(location));
                if (track.size() > 500) track.remove(0);
            }
        }
        gpsView.invalidate();
    }
    @Override public void onProviderEnabled(String provider) { status = "GPS فعال شد؛ در حال جست‌وجو…"; gpsView.invalidate(); }
    @Override public void onProviderDisabled(String provider) { status = "GPS خاموش است"; gpsView.invalidate(); }
    @Override public void onStatusChanged(String provider, int s, Bundle extras) {}

    @Override public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            float[] matrix = new float[9];
            float[] orientation = new float[3];
            SensorManager.getRotationMatrixFromVector(matrix, event.values);
            SensorManager.getOrientation(matrix, orientation);
            heading = (float) ((Math.toDegrees(orientation[0]) + 360.0) % 360.0);
            if (gpsView != null) gpsView.invalidate();
        }
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override protected void onResume() { super.onResume(); if (hasFineLocation()) startGps(); }
    @Override protected void onPause() { stopGps(); super.onPause(); }
    @Override protected void onDestroy() { stopGps(); super.onDestroy(); }

    private String coordinate(double value, boolean latitude) {
        char hemi = latitude ? (value >= 0 ? 'N' : 'S') : (value >= 0 ? 'E' : 'W');
        double a = Math.abs(value);
        int deg = (int) a;
        double mins = (a - deg) * 60.0;
        int min = (int) mins;
        double sec = (mins - min) * 60.0;
        return String.format(Locale.US, "%c %0" + (latitude ? "2" : "3") + "d° %02d' %04.1f\"", hemi, deg, min, sec);
    }

    private class GpsView extends View {
        private final Paint p = new Paint(3);
        private final float density;
        private int page = 0;
        private boolean light = true;
        private boolean menu = false;
        private long downAt;
        private float downX, downY;
        private final RectF[] keys = new RectF[8];
        private final String[] keyNames = {"PAGE", "QUIT", "MENU", "ENTER", "GOTO", "LIGHT", "▲", "▼"};
        GpsView(Context c) { super(c); density = getResources().getDisplayMetrics().density; setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        private void fill(Canvas c, int color, float l,float t,float r,float b,float radius) { p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(l,t,r,b,radius,radius,p); }
        private void text(Canvas c, String s, float x,float y,float size,int color, boolean bold) { p.setColor(color); p.setTextSize(size); p.setTypeface(bold?android.graphics.Typeface.create("sans-serif",1):android.graphics.Typeface.create("monospace",0)); p.setTextAlign(Paint.Align.CENTER); c.drawText(s,x,y,p); }
        private void line(Canvas c,float x1,float y1,float x2,float y2,int color,float w) { p.setColor(color);p.setStrokeWidth(w);p.setStyle(Paint.Style.STROKE);c.drawLine(x1,y1,x2,y2,p);p.setStyle(Paint.Style.FILL); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float sx=getWidth()/360f, sy=getHeight()/780f, scale=Math.min(sx,sy);
            canvas.save(); canvas.scale(scale,scale); canvas.translate((getWidth()/scale-360)/2,(getHeight()/scale-780)/2);
            int bg=Color.rgb(35,38,39), body=Color.rgb(18,20,21), lcd=light?Color.rgb(169,204,126):Color.rgb(91,111,70), ink=Color.rgb(20,32,12);
            canvas.drawColor(bg);
            fill(canvas,body,22,18,338,762,42);
            text(canvas,"GARMIN",180,67,21,Color.LTGRAY,true);
            fill(canvas,Color.rgb(4,5,5),48,92,312,440,8);
            fill(canvas,lcd,57,101,303,431,3);
            drawLcd(canvas,ink,lcd);
            // Physical keys
            drawKey(canvas,52,476,118,520,"PAGE"); drawKey(canvas,190,476,256,520,"QUIT");
            drawKey(canvas,52,535,118,579,"MENU"); drawKey(canvas,190,535,256,579,"ENTER");
            drawKey(canvas,52,594,118,638,"GOTO"); drawKey(canvas,190,594,256,638,"LIGHT");
            fill(canvas,Color.rgb(35,37,38),270,478,318,634,24);
            drawKey(canvas,277,482,311,525,"▲"); drawKey(canvas,277,535,311,578,"▼");
            text(canvas,"GPS 72",180,700,22,Color.LTGRAY,true);
            text(canvas,"موقعیت‌یاب مستقل اندروید",180,729,12,Color.LTGRAY,false);
            canvas.restore();
        }
        private void drawKey(Canvas c,float l,float t,float r,float b,String label){fill(c,Color.rgb(64,68,69),l,t,r,b,13);p.setColor(Color.rgb(110,115,116));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);c.drawRoundRect(l+1,t+1,r-1,b-1,12,12,p);p.setStyle(Paint.Style.FILL);text(c,label,(l+r)/2,(t+b)/2+5,13,Color.WHITE,true);}
        private void drawLcd(Canvas c,int ink,int lcd){
            text(c,new String[]{"SATELLITE","MAP / TRACK","HIGHWAY","POSITION","GPS MENU"}[page],180,124,12,ink,true);
            line(c,65,132,295,132,ink,1);
            if(page==0){
                float cx=180,cy=242,rad=82;
                p.setColor(ink);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);c.drawCircle(cx,cy,rad,p);c.drawCircle(cx,cy,rad/2,p);p.setStyle(Paint.Style.FILL);
                line(c,cx-rad,cy,cx+rad,cy,ink,1);line(c,cx,cy-rad,cx,cy+rad,ink,1);text(c,"N",cx,cy-rad-8,11,ink,true);
                for(int i=0;i<Math.min(satellites,12);i++){float a=(float)(i*2.399);float x=cx+(float)Math.sin(a)*rad*.72f;float y=cy-(float)Math.cos(a)*rad*.72f;fill(c,ink,x-8,y-7,x+8,y+7,2);text(c,""+(i+1),x,y+4,9,lcd,true);}
                text(c,"ماهواره‌های استفاده‌شده: "+satellites,180,354,13,ink,true);
                text(c,lastLocation==null?"در انتظار دریافت GPS":"موقعیت واقعی دریافت شد",180,382,12,ink,false);
                text(c,status,180,410,10,ink,false);
            } else if(page==1){
                text(c,"نقشه و مسیر ثبت‌شده",180,190,14,ink,true);
                p.setColor(ink);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);Path path=new Path();
                for(int i=0;i<track.size();i++){Location l=track.get(i);float x=180+(float)((l.getLongitude()-lastLocation.getLongitude())*100000);float y=260-(float)((l.getLatitude()-lastLocation.getLatitude())*100000);if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);
                text(c,"نقاط مسیر: "+track.size(),180,390,12,ink,false);
            } else if(page==2){
                text(c,"GPS NAVIGATION",180,190,15,ink,true);
                text(c,"سرعت",120,245,12,ink,false);text(c,lastLocation!=null&&lastLocation.hasSpeed()?String.format(Locale.US,"%.1f km/h",lastLocation.getSpeed()*3.6):"--",120,280,21,ink,true);
                text(c,"جهت حرکت",240,245,12,ink,false);text(c,lastLocation!=null&&lastLocation.hasBearing()?String.format(Locale.US,"%.0f°",lastLocation.getBearing()):"--",240,280,21,ink,true);
            } else if(page==3){
                if(lastLocation==null){text(c,"مختصات هنوز دریافت نشده",180,235,14,ink,true);text(c,"به فضای باز برو و چند لحظه صبر کن",180,270,11,ink,false);}else{
                    text(c,"LATITUDE",180,177,11,ink,true);text(c,coordinate(lastLocation.getLatitude(),true),180,207,15,ink,true);
                    text(c,"LONGITUDE",180,250,11,ink,true);text(c,coordinate(lastLocation.getLongitude(),false),180,280,15,ink,true);
                    text(c,"ALT  "+(lastLocation.hasAltitude()?String.format(Locale.US,"%.1f m",lastLocation.getAltitude()):"--"),115,333,12,ink,true);
                    text(c,"ACC  "+String.format(Locale.US,"%.1f m",lastLocation.getAccuracy()),235,333,12,ink,true);
                    text(c,"SPD  "+(lastLocation.hasSpeed()?String.format(Locale.US,"%.1f km/h",lastLocation.getSpeed()*3.6):"0.0 km/h"),180,367,12,ink,true);
                }
                text(c,"COMPASS  "+(Float.isNaN(heading)?"--":String.format(Locale.US,"%.0f°",heading)),180,405,12,ink,true);
            } else {
                text(c,"منوی GPS 72",180,185,15,ink,true);
                text(c,tracking?"ثبت مسیر: روشن":"ثبت مسیر: خاموش",180,230,13,ink,false);
                text(c,"ENTER: شروع / توقف مسیر",180,270,11,ink,false);
                text(c,"LIGHT: نور صفحه",180,300,11,ink,false);
                text(c,"PAGE / QUIT: جابه‌جایی صفحات",180,330,11,ink,false);
                text(c,"منبع موقعیت: GPS واقعی اندروید",180,370,11,ink,true);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            float scale=Math.min(getWidth()/360f,getHeight()/780f);float x=e.getX()/scale-(getWidth()/scale-360)/2;float y=e.getY()/scale-(getHeight()/scale-780)/2;
            if(e.getAction()==MotionEvent.ACTION_DOWN){downX=x;downY=y;downAt=System.currentTimeMillis();return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){long held=System.currentTimeMillis()-downAt;
                if(y>470&&y<530){if(x<145)page=(page+1)%5;else if(x<265)page=(page+4)%5;}
                else if(y>=530&&y<590){if(x<145)page=4;else if(x<265){if(page==4){tracking=!tracking;if(!tracking)status="ثبت مسیر متوقف شد";else status="ثبت مسیر فعال شد";}else page=3;}}
                else if(y>=590&&y<650){if(x<145)page=2;else light=!light;}
                else if(x>265&&y>470&&y<640){if(y<530)page=(page+4)%5;else page=(page+1)%5;}
                else if(y>=100&&y<440){if(x<100)page=(page+4)%5;else if(x>260)page=(page+1)%5;}
                invalidate();return true;}
            return true;
        }
    }
}
